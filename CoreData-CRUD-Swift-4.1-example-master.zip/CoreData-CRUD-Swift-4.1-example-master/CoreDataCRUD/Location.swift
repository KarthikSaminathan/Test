//
//  Location.swift
//  CoreDataCRUD
//
//  Copyright © 2016 Jongens van Techniek. All rights reserved.
//

import Foundation
import CoreData

class Location: NSManagedObject {

// Insert code here to add functionality to your managed object subclass
    @NSManaged var event: Event?

}
